<?php
/**
 * Gizli Bilgiler - Bu dosya Git'e eklenmez.
 * cPanel'e yükledikten sonra bu dosyayı düzenleyin.
 */

// Claude API Anahtarı
define('ENV_CLAUDE_API_KEY', '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');

// Veritabanı Şifresi
define('ENV_DB_PASS', 'MrHasar2025!');
